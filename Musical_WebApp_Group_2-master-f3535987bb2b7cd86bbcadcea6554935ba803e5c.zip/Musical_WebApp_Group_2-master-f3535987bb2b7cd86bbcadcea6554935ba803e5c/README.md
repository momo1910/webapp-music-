# MASTER लिरिक्स

> A Vue.js project using cli 2<br>
> It use vuetify framework for material design<br>
> Backend is based on SQLite<br>
> Contributers:-<br>
> > Avais Ahmad <br>
> > Debashish Deka<br>
> > Dhananjay Sharma<br>
> > Lokesh Yadav<br>
> > Priti Sharma<br>
> > Sayali Borkar<br>


## Build Setup

``` bash
#For client
cd client
npm install 

#For server
cd server
npm install

#Use chrome as
google-chrome --disable-web-security --user-data-dir="/tmp/"
```
<br>
switch to your brach (important)<br>
Do your work<br>
commit it<br>
push it<br>
raise pull request<br>
<br>
For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
